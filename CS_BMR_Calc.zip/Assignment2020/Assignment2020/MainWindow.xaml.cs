﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment2020
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        string AgeText = "15 - 80"; string HeightText; string WeightText; double Result;

        private void TittleBar_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void MouseHover(object sender, MouseEventArgs e)
        {
            CloseButtonHover.Visibility = Visibility.Visible;
        }

        private void MouseLeaveHover(object sender, MouseEventArgs e)
        {
            CloseButtonHover.Visibility = Visibility.Hidden;
        }

        private void closeButton(object sender, MouseButtonEventArgs e)
        {
            CloseButtonPressed.Visibility = Visibility.Visible;
        }

        private void AgeTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            
            if (AgeTextBox.Text.All(char.IsDigit))
            {
                AgeText = AgeTextBox.Text;
            }
            else
            {
                AgeTextBox.Text = AgeText;
            }
        }

        private void AgeTextBox_Click(object sender, MouseButtonEventArgs e)
        {
            AgeTextBox.Text = "";
            AgeTextBoxFirstClick.Visibility = Visibility.Hidden;
            AgeTextBox.Foreground = new SolidColorBrush(Colors.White);
            AgeTextBox.Focus();
        }

        private void AgeTextBoxClickOut(object sender, RoutedEventArgs e)
        {
            if (AgeTextBox.Text == " " || AgeTextBox.Text == "" || AgeTextBox.Text == "15 - 80 ")
            {
                AgeTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                Required1.Visibility = Visibility.Visible;
                AgeTextBoxFirstClick.Visibility = Visibility.Visible;
                AgeText = "15 - 80 ";
                AgeTextBox.Text = "15 - 80 ";
                AgeTextBox.Foreground = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255));
            }
            else if (AgeTextBox.Text != " " && AgeTextBox.Text != "")
            {
                AgeTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                Required1.Visibility = Visibility.Hidden;
            }
        }

        private void CloseButtonReleased(object sender, MouseButtonEventArgs e)
        {

            if (CloseButtonPressed.IsMouseOver == true)
            {
                Close();
            }
        }

        private void MouseUpMainWindow(object sender, MouseButtonEventArgs e)
        {
            if (CloseButtonPressed.Visibility == Visibility.Visible)
            {
                CloseButtonPressed.Visibility = Visibility.Hidden;
            }
            if (MinimizePressed.Visibility == Visibility.Visible){
               
                MinimizePressed.Visibility = Visibility.Hidden;
                MinimizeButton.Visibility = Visibility.Visible;
            }
            if (calcPressed.Visibility == Visibility.Visible)
            {
                calcButton.Visibility = Visibility.Visible;
                calcPressed.Visibility = Visibility.Hidden;
            }
            if (clearPressed.Visibility == Visibility.Visible)
            {
                clearButton.Visibility = Visibility.Visible;
                clearPressed.Visibility = Visibility.Hidden;
            }
        }

        private void minimizeButton(object sender, MouseButtonEventArgs e)
        {
            MinimizePressed.Visibility = Visibility.Visible;
            MinimizeHover.Visibility = Visibility.Hidden;
            MinimizeButton.Visibility = Visibility.Hidden;

        }

        private void minimizeHover(object sender, MouseEventArgs e)
        {
            MinimizeHover.Visibility = Visibility.Visible;

        }

        private void minimizeLeaveHover(object sender, MouseEventArgs e)
        {
            MinimizeHover.Visibility = Visibility.Hidden;

        }

        private void MouseLeaveMain(object sender, MouseEventArgs e)
        {
            if (CloseButtonPressed.Visibility == Visibility.Visible)
            {
                CloseButtonPressed.Visibility = Visibility.Hidden;
            }
            if (MinimizePressed.Visibility == Visibility.Visible)
            {

                MinimizePressed.Visibility = Visibility.Hidden;
                MinimizeButton.Visibility = Visibility.Visible;
            }
            if (calcPressed.Visibility == Visibility.Visible)
            {
                calcButton.Visibility = Visibility.Visible;
                calcPressed.Visibility = Visibility.Hidden;
            }
            if (clearPressed.Visibility == Visibility.Visible)
            {
                clearButton.Visibility = Visibility.Visible;
                clearPressed.Visibility = Visibility.Hidden;
            }
        }

        private void minimizeMouseUp(object sender, MouseButtonEventArgs e)
        {
            if (MinimizePressed.IsMouseOver == true)
            {
                this.WindowState = WindowState.Minimized;
            }
        }

        private void HeightTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (HeightTextBox.Text.All(char.IsDigit))
            {
                HeightText = HeightTextBox.Text;
            }
            else
            {
                HeightTextBox.Text = HeightText;
            }
        }

        private void WeightTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (WeightTextBox.Text.All(char.IsDigit))
            {
                WeightText = WeightTextBox.Text;
            }
            else
            {
                WeightTextBox.Text = WeightText;
            }

        }

        private void HeightTextBoxClickOut(object sender, RoutedEventArgs e)
        {
            if (HeightTextBox.Text == " " || HeightTextBox.Text == "")
            {
                HeightTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                Required2.Visibility = Visibility.Visible;
            }
            else if (HeightTextBox.Text != " " && HeightTextBox.Text != "")
            {
                HeightTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                Required2.Visibility = Visibility.Hidden;
            }
        }

        private void WeightTextBoxClickOut(object sender, RoutedEventArgs e)
        {
            if (WeightTextBox.Text == " " || WeightTextBox.Text == "")
            {
                WeightTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                Required3.Visibility = Visibility.Visible;
            }
            else if (WeightTextBox.Text != " " && WeightTextBox.Text != "")
            {
                WeightTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                Required3.Visibility = Visibility.Hidden;
            }
        }

        private void calcMouseOver(object sender, MouseEventArgs e)
        {
            calcHover.Visibility = Visibility.Visible;
        }

        private void clearMouseOver(object sender, MouseEventArgs e)
        {
            clearHover.Visibility = Visibility.Visible;
        }

        private void calcMouseLeave(object sender, MouseEventArgs e)
        {
            calcHover.Visibility = Visibility.Hidden;
        }

        private void clearMouseLeave(object sender, MouseEventArgs e)
        {
            clearHover.Visibility = Visibility.Hidden;
        }

        private void calcMouseClick(object sender, MouseButtonEventArgs e)
        {
            calcButton.Visibility = Visibility.Hidden;
            calcHover.Visibility = Visibility.Hidden;
            calcPressed.Visibility = Visibility.Visible;
        }

        private void clearMouseClick(object sender, MouseButtonEventArgs e)
        {
            clearButton.Visibility = Visibility.Hidden;
            clearHover.Visibility = Visibility.Hidden;
            clearPressed.Visibility = Visibility.Visible;
        }

        private void calcMouseUp(object sender, MouseButtonEventArgs e)
        {
            calcButton.Visibility = Visibility.Visible;
            calcPressed.Visibility = Visibility.Hidden;

            if (calcPressed.IsMouseOver == true)
            {
                if (AgeTextBox.Text == " " || AgeTextBox.Text == "" || AgeTextBox.Text == "15 - 80")
                {
                    AgeTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                    Required1.Visibility = Visibility.Visible;
                    AgeTextBoxFirstClick.Visibility = Visibility.Visible;
                    AgeText = "15 - 80";
                    AgeTextBox.Text = "15 - 80";
                    AgeTextBox.Foreground = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255));
                }
              
                int.TryParse(AgeTextBox.Text, out int Age);
                 
                if (Age < 15 || Age > 80)
                {
                    AgeTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                    Required1.Visibility = Visibility.Visible;
                    AgeTextBoxFirstClick.Visibility = Visibility.Visible;
                   AgeText = "Age must be 15 - 80";
                    AgeTextBox.Text = "Age must be 15 - 80";
                    AgeTextBox.Foreground = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255));
                }


                if (HeightTextBox.Text == " " || HeightTextBox.Text == "")
                {
                    HeightTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                    Required2.Visibility = Visibility.Visible;
                }

                if (WeightTextBox.Text == " " || WeightTextBox.Text == "")
                {
                    WeightTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                    Required3.Visibility = Visibility.Visible;
                }

                if (AgeTextBox.Text == " " || AgeTextBox.Text == "" || AgeTextBox.Text == "15 - 80 " || AgeTextBox.Text == "Age must be 15 - 80")
                {
                    AgeTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                    Required1.Visibility = Visibility.Visible;
                    AgeTextBoxFirstClick.Visibility = Visibility.Visible;
                    AgeText = "Age must be 15 - 80";
                    AgeTextBox.Text = "Age must be 15 - 80";
                    AgeTextBox.Foreground = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255));
                }
                else if (AgeTextBox.Text != " " && AgeTextBox.Text != "")
                {
                    AgeTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                    Required1.Visibility = Visibility.Hidden;
                }

                if (HeightTextBox.Text == " " || HeightTextBox.Text == "")
                {
                    HeightTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                    Required2.Visibility = Visibility.Visible;
                }
                else if (HeightTextBox.Text != " " && HeightTextBox.Text != "")
                {
                    HeightTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                    Required2.Visibility = Visibility.Hidden;
                }

                if (WeightTextBox.Text == " " || WeightTextBox.Text == "")
                {
                    WeightTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                    Required3.Visibility = Visibility.Visible;
                }
                else if (WeightTextBox.Text != " " && WeightTextBox.Text != "")
                {
                    WeightTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                    Required3.Visibility = Visibility.Hidden;
                }


                if (Required1.Visibility == Visibility.Hidden && Required2.Visibility == Visibility.Hidden && Required3.Visibility == Visibility.Hidden)
                {
                    double.TryParse(AgeTextBox.Text, out double intAge);
                    double.TryParse(WeightTextBox.Text, out double intWeight);
                    double.TryParse(HeightTextBox.Text, out double intHeigh);

                    if (male.IsChecked == true)
                    {
                        Result = (10 * intWeight) + (6.25 * intHeigh) - (5 * intAge) + 5;
                        resultLabel.Content = Result;
                        bmrLabel.Visibility = Visibility.Visible;
                        resultLabel.Visibility = Visibility.Visible;
                        caloriesLabel.Visibility = Visibility.Visible;
                    }
                    else if (female.IsChecked == true)
                    {

                        Result = (10 * intWeight) + (6.25 * intHeigh) - (5 * intAge) - 161;
                        resultLabel.Content = Result;
                        bmrLabel.Visibility = Visibility.Visible;
                        resultLabel.Visibility = Visibility.Visible;
                        caloriesLabel.Visibility = Visibility.Visible;
                    }
                }
            
            }

        }

        private void clearMouseUp(object sender, MouseButtonEventArgs e)
        {
            clearButton.Visibility = Visibility.Visible;
            clearPressed.Visibility = Visibility.Hidden;

            bmrLabel.Visibility = Visibility.Hidden;
            resultLabel.Visibility = Visibility.Hidden;
            caloriesLabel.Visibility = Visibility.Hidden;


            if (clearPressed.IsMouseOver == true)
            {
                MainRectangle.Focus();

                AgeText = "15 - 80";
                AgeTextBox.Text = "15 - 80";
                AgeTextBoxFirstClick.Visibility = Visibility.Visible;
                HeightText = "";
                HeightTextBox.Text = "";
                WeightText = "";
                WeightTextBox.Text = "";

                AgeTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                Required1.Visibility = Visibility.Hidden;
                AgeTextBox.Foreground = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255));

                HeightTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                Required2.Visibility = Visibility.Hidden;

                WeightTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                Required3.Visibility = Visibility.Hidden;
               
                
            }

        }

        private void MouseClickMain(object sender, MouseButtonEventArgs e)
        {

        }

        private void MainKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {

                    if (AgeTextBox.Text == " " || AgeTextBox.Text == "" || AgeTextBox.Text == "15 - 80")
                    {
                        AgeTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                        Required1.Visibility = Visibility.Visible;
                        AgeTextBoxFirstClick.Visibility = Visibility.Visible;
                        AgeText = "15 - 80";
                        AgeTextBox.Text = "15 - 80";
                        AgeTextBox.Foreground = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255));
                    }

                    int.TryParse(AgeTextBox.Text, out int Age);

                    if (Age < 15 || Age > 80)
                    {
                        AgeTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                        Required1.Visibility = Visibility.Visible;
                        AgeTextBoxFirstClick.Visibility = Visibility.Visible;
                        AgeText = "Age must be 15 - 80";
                        AgeTextBox.Text = "Age must be 15 - 80";
                        AgeTextBox.Foreground = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255));
                    }


                    if (HeightTextBox.Text == " " || HeightTextBox.Text == "")
                    {
                        HeightTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                        Required2.Visibility = Visibility.Visible;
                    }

                    if (WeightTextBox.Text == " " || WeightTextBox.Text == "")
                    {
                        WeightTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                        Required3.Visibility = Visibility.Visible;
                    }

                    if (AgeTextBox.Text == " " || AgeTextBox.Text == "" || AgeTextBox.Text == "15 - 80 " || AgeTextBox.Text == "Age must be 15 - 80")
                    {
                        AgeTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                        Required1.Visibility = Visibility.Visible;
                        AgeTextBoxFirstClick.Visibility = Visibility.Visible;
                        AgeText = "Age must be 15 - 80";
                        AgeTextBox.Text = "Age must be 15 - 80";
                        AgeTextBox.Foreground = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255));
                    }
                    else if (AgeTextBox.Text != " " && AgeTextBox.Text != "")
                    {
                        AgeTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                        Required1.Visibility = Visibility.Hidden;
                    }

                    if (HeightTextBox.Text == " " || HeightTextBox.Text == "")
                    {
                        HeightTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                        Required2.Visibility = Visibility.Visible;
                    }
                    else if (HeightTextBox.Text != " " && HeightTextBox.Text != "")
                    {
                        HeightTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                        Required2.Visibility = Visibility.Hidden;
                    }

                    if (WeightTextBox.Text == " " || WeightTextBox.Text == "")
                    {
                        WeightTextRectangle.Stroke = new SolidColorBrush(Colors.Red);
                        Required3.Visibility = Visibility.Visible;
                    }
                    else if (WeightTextBox.Text != " " && WeightTextBox.Text != "")
                    {
                        WeightTextRectangle.Stroke = new SolidColorBrush(Colors.Black);
                        Required3.Visibility = Visibility.Hidden;
                    }


                    if (Required1.Visibility == Visibility.Hidden && Required2.Visibility == Visibility.Hidden && Required3.Visibility == Visibility.Hidden)
                    {
                        double.TryParse(AgeTextBox.Text, out double intAge);
                        double.TryParse(WeightTextBox.Text, out double intWeight);
                        double.TryParse(HeightTextBox.Text, out double intHeigh);

                        if (male.IsChecked == true)
                        {
                            Result = (10 * intWeight) + (6.25 * intHeigh) - (5 * intAge) + 5;
                            resultLabel.Content = Result;
                            bmrLabel.Visibility = Visibility.Visible;
                            resultLabel.Visibility = Visibility.Visible;
                            caloriesLabel.Visibility = Visibility.Visible;
                        }
                        else if (female.IsChecked == true)
                        {

                            Result = (10 * intWeight) + (6.25 * intHeigh) - (5 * intAge) - 161;
                            resultLabel.Content = Result;
                            bmrLabel.Visibility = Visibility.Visible;
                            resultLabel.Visibility = Visibility.Visible;
                            caloriesLabel.Visibility = Visibility.Visible;
                        }


                    }

                

            }
        }
    }
}
